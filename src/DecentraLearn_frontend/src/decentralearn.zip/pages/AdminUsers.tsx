import React from 'react'

function AdminUsers() {
  return (
    <div>AdminUsers</div>
  )
}

export default AdminUsers